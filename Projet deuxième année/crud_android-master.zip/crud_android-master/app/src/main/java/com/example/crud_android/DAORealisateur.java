package com.example.crud_android;

public interface DAORealisateur {
}
