package com.example.crud_android;

import androidx.room.*;

import java.util.List;

@Dao
public interface DAOFilm {

    @Query("SELECT * FROM Film")
    List<Film> getAll();

    @Query("SELECT * FROM Film WHERE id IN (:userIds)")
    List<Film> loadAllByIds(int[] userIds);


    @Insert
    void insertAll(Film... users);

    @Delete
    void delete(Film user);

}
