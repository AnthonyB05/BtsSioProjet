package com.example.crud_android;

import androidx.room.*;

@Entity
public class Realisateur {
    @PrimaryKey
    public int id;

    @ColumnInfo(name = "Nom")
    public String nom;

    @ColumnInfo(name = "Prenom")
    public String prenom;



}

