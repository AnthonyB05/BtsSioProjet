package com.example.crud_android;

import androidx.room.Database;
import androidx.room.RoomDatabase;


@Database(entities = {Film.class}, version = 1)
public abstract class BaseDonnee extends RoomDatabase {
    public abstract DAOFilm DAOFilm();
}
