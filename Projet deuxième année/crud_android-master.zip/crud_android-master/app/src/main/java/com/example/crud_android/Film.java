package com.example.crud_android;

import androidx.room.*;

@Entity
public class Film {
    @PrimaryKey
    public int id;

    @ColumnInfo(name = "Titre")
    public String titre;

    @ColumnInfo(name = "Année")
    public String annee;

    @ColumnInfo(name = "Genre")
    public String genre;

    @ColumnInfo(name = "Durée")
    public String duree;

    @ColumnInfo(name = "Note")
    public String note;
}

