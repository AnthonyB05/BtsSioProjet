package com.example.crud_android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Accueil extends AppCompatActivity {

    private String choix;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.accueil);

        spinner= (Spinner) findViewById(R.id.spinner);
        spinner();


    }
    public void spinner(){

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

    }

    public void exit(View view) {
        finish();
    }

    public void ajouter(View view) {

        choix=spinner.getSelectedItem().toString();
        System.out.println(choix);


        if (choix.equals("Film")){
            Intent r= new Intent (this,FilmAjoute.class);
            finish();
            startActivity(r);
        }
        if (choix.equals("Realisateur")){

        }

    }
}


