package com.example.telethon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Pas de sauvegarde extérieure pour le moment donc le fais de ne pas refaire les QCM marche tant qu on ne quitte pas l'application
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void pageQcm(View view) {

       Intent intentQcm = new Intent (this, PageQCM.class);
       finish();
       startActivity(intentQcm);
    }


    public void jsonEnvoi(View view) {
        Intent json = new Intent (this, JSON_Envoi.class);
        finish();
        startActivity(json);
    }

    public void jsonRecup(View view) {
        Intent json = new Intent (this, JSON_Recup.class);
        finish();
        startActivity(json);
    }


}