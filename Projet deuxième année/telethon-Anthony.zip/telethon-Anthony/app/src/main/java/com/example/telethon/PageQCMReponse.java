package com.example.telethon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class PageQCMReponse extends AppCompatActivity {
    TextView TxtRep;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_c_m_reponse);
        Intent reponse = getIntent();
        String rep= reponse.getStringExtra("rep");
        TxtRep = findViewById(R.id.rep);
        TxtRep.setText(rep);

    }

    public void Accueil(View view) {
        Intent accueil = new Intent (this, MainActivity.class);
        finish();
        startActivity(accueil);
    }
}