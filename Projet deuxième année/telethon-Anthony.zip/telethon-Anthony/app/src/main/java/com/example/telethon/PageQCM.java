package com.example.telethon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class PageQCM extends AppCompatActivity {
    int reponse=2;
    TextView question;
    RadioButton rB1, rB2, rB3, rB4;
    public static final List<Integer> nombre_passer= new ArrayList<>();

    private RequestQueue mQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_c_m);

        mQueue = Volley.newRequestQueue(this);
        question = findViewById(R.id.Question);
        rB1 = findViewById(R.id.R1);
        rB2 = findViewById(R.id.R2);
        rB3 = findViewById(R.id.R3);
        rB4 = findViewById(R.id.R4);

        jsonParse();
    }
    private void jsonParse() {

        // lien local
        // String url = "http://192.168.219.231/saj/serviceTelethon.php";

        // lien distant
        String url = "http://193.253.50.77:20231/saj/serviceTelethon.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {

                        JSONArray jsonArray = response.getJSONArray("qcm");
                        int nombre = 0;
                        for (int i = 0; i < jsonArray.length(); i++) {

                            QCM qcm = new QCM();
                            JSONObject participant = jsonArray.getJSONObject(i);

                            qcm.setId_qcm(participant.getInt("id_qcm"));
                            qcm.setId_partipitant_U(participant.getInt("id_participant_U"));
                            qcm.setLibelle_question(participant.getString("libelle_question"));
                            qcm.setProposition_1(participant.getString("proposition_1"));
                            qcm.setProposition_2(participant.getString("proposition_2"));
                            qcm.setProposition_3(participant.getString("proposition_3"));
                            qcm.setProposition_4(participant.getString("proposition_4"));
                            qcm.setBonne_reponse(participant.getInt("bonne_reponse"));
                            qcm.setAuteur(participant.getString("auteur"));

                            // Récupérer information de la database pour un PageQCM aléatoirea
                            // faire en sorte de ne pas resortir le même PageQCM plusieurs fois
                            if (!nombre_passer.contains(qcm.getId_qcm())){
                                System.out.println(qcm.getId_qcm());
                                nombre_passer.add(qcm.getId_qcm());
                                question.setText(qcm.getLibelle_question());
                                rB1.setText(qcm.getProposition_1());
                                rB2.setText(qcm.getProposition_2());
                                rB3.setText(qcm.getProposition_3());
                                rB4.setText(qcm.getProposition_4());
                                reponse = qcm.getBonne_reponse();

                                break;
                            }
                            nombre++;
                            if (nombre == jsonArray.length()){
                                complet();
                            }

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }, error -> error.printStackTrace());
        mQueue.add(request);
    }

    public void annuler(View view) {
        Intent annuler = new Intent (this, MainActivity.class);
        finish();
        startActivity(annuler);
    }

    public void valider(View view) {

        if (rB1.isChecked()==true){
           if (rB1.getTag().equals(String.valueOf(reponse))) {
               vrai();
           }else{
               faux();
           }
        }else if (rB2.isChecked()==true){
            if (rB2.getTag().equals(String.valueOf(reponse))) {
                vrai();
            }else{
                faux();
            }
        }else if (rB3.isChecked()==true){
            if (rB3.getTag().equals(String.valueOf(reponse))) {
                vrai();
            }else{
                faux();
            }
        }else if(rB4.isChecked()==true){
            if (rB4.getTag().equals(String.valueOf(reponse))) {
                vrai();
            }else{
                faux();
            }
        }
    }

    /**
     * Fonction qui renvoie une page pour signaler qu'il n'y a plus de QCM à compléter
     */
    public void complet(){
        Intent complet = new Intent (this, PageQCMNull.class);
        System.out.println("plus de QCM à compléter");
        finish();
        startActivity(complet);
    }

    /**
     * Fonction pour collecter les bonnes réponses et permettre de faire un score en aval
     */
    public void vrai(){
        Intent vrai = new Intent (this, PageQCMReponse.class);
        String StrVrai = "Bonne réponse";
        finish();
        vrai.putExtra("rep",StrVrai);
        startActivity(vrai);
    }

    /**
     * Fonction pour collecter les mauvaises réponses et permettre de faire un score en aval
     */
    public void faux(){
        Intent faux = new Intent (this, PageQCMReponse.class);
        String StrFaux = "Mauvaise réponse";
        finish();
        faux.putExtra("rep",StrFaux);
        startActivity(faux);
    }


}