package com.example.telethon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JSON_Recup extends AppCompatActivity {
    private TextView Result;
    private RequestQueue mQueue;
    public static final List<Integer> nombre_passer= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_j_s_o_n__recup);
        Result= findViewById(R.id.text_view_result);

        mQueue = Volley.newRequestQueue(this);
    }

    public void json(View view) {
        jsonParse();
    }

    // Récupération des données JSON avec "volley"
    private void jsonParse() {
        // lien local
        // String url = "http://192.168.219.231/saj/serviceTelethon.php";

        // lien distant
        String url = "http://193.253.50.77:20231/saj/serviceTelethon.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray jsonArray = response.getJSONArray("qcm");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            QCM qcm = new QCM();
                            JSONObject participant = jsonArray.getJSONObject(i);

                            qcm.setId_qcm(participant.getInt("id_qcm"));
                            qcm.setId_partipitant_U(participant.getInt("id_participant_U"));
                            qcm.setLibelle_question(participant.getString("libelle_question"));
                            qcm.setProposition_1(participant.getString("proposition_1"));
                            qcm.setProposition_2(participant.getString("proposition_2"));
                            qcm.setProposition_3(participant.getString("proposition_3"));
                            qcm.setProposition_4(participant.getString("proposition_4"));
                            qcm.setBonne_reponse(participant.getInt("bonne_reponse"));
                            qcm.setAuteur(participant.getString("auteur"));

                            if (!nombre_passer.contains(qcm.getId_qcm())){
                                System.out.println(qcm.getId_qcm());
                                nombre_passer.add(qcm.getId_qcm());
                                Result.append(qcm.getId_qcm() + ", " + qcm.getId_partipitant_U() + ", " + qcm.getLibelle_question() + ", " +
                                        qcm.getProposition_1() + ", " + qcm.getProposition_2() +", " + qcm.getProposition_3() +", "
                                        + qcm.getProposition_4() +", " + qcm.getBonne_reponse() +", "
                                        + qcm.getAuteur() +  "\n\n");
                                break;
                            }


                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }, error -> error.printStackTrace());
        mQueue.add(request);
    }

    public void annuler(View view) {
        Intent annuler = new Intent (this, MainActivity.class);
        finish();
        startActivity(annuler);
    }
}