package com.example.telethon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class JSON_Envoi extends AppCompatActivity {

    private EditText nom , prenom, login, mdp;
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_j_s_o_n__envoi);

        nom = findViewById(R.id.nom);
        prenom = findViewById(R.id.prenom);
        login = findViewById(R.id.login);
        mdp = findViewById(R.id.mdp);

        mQueue = Volley.newRequestQueue(this);
    }

    public void envoi(View view) {
        Submit(nom.getText().toString(), prenom.getText().toString(), login.getText().toString(), mdp.getText().toString());
    }

    private void Submit(String nom, String prenom, String login, String mdp)
    {
        // lien local
        // String url = "http://192.168.219.231/saj/InsertParticipant.php";

        // lien distant
        String URL="http://193.253.50.77:20231/saj/InsertParticipant.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object=new JSONObject(response);
                    Toast.makeText(getApplicationContext(),object.toString(),Toast.LENGTH_LONG).show();


                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(),"Server Error",Toast.LENGTH_LONG).show();

                }
                //Log.i("VOLLEY", response);
            }
        }, error -> {

            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();

            Log.v("VOLLEY", error.toString());
        }) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<>();

                params.put("nom", nom);
                params.put("prenom", prenom);
                params.put("login", login);
                params.put("mdp", mdp);

                return params;
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }


        };
        mQueue.add(stringRequest);
    }
}
