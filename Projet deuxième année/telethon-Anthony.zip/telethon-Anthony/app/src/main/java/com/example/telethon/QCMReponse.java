package com.example.telethon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class QCMReponse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_c_m_reponse);
    }

    public void Accueil(View view) {
        Intent accueil = new Intent (this, MainActivity.class);
        finish();
        startActivity(accueil);
    }
}