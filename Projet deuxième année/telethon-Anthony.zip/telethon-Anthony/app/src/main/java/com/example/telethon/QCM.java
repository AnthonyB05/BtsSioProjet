package com.example.telethon;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class QCM implements Serializable {

    int id_qcm;
    int id_partipitant_U;
    String libelle_question;
    String proposition_1;
    String proposition_2;
    String proposition_3;
    String proposition_4;
    int bonne_reponse;
    String auteur;

    public int getId_qcm() {
        return id_qcm;
    }

    public void setId_qcm(int id_qcm) {
        this.id_qcm = id_qcm;
    }

    public int getId_partipitant_U() {
        return id_partipitant_U;
    }

    public void setId_partipitant_U(int id_partipitant_U) {
        this.id_partipitant_U = id_partipitant_U;
    }

    public String getLibelle_question() {
        return libelle_question;
    }

    public void setLibelle_question(String libelle_question) {
        this.libelle_question = libelle_question;
    }

    public String getProposition_1() {
        return proposition_1;
    }

    public void setProposition_1(String proposition_1) {
        this.proposition_1 = proposition_1;
    }

    public String getProposition_2() {
        return proposition_2;
    }

    public void setProposition_2(String proposition_2) {
        this.proposition_2 = proposition_2;
    }

    public String getProposition_3() {
        return proposition_3;
    }

    public void setProposition_3(String proposition_3) {
        this.proposition_3 = proposition_3;
    }

    public String getProposition_4() {
        return proposition_4;
    }

    public void setProposition_4(String proposition_4) {
        this.proposition_4 = proposition_4;
    }

    public int getBonne_reponse() {
        return bonne_reponse;
    }

    public void setBonne_reponse(int bonne_reponse) {
        this.bonne_reponse = bonne_reponse;
    }

    public String getAuteur() {
        return auteur;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    @Override
    public String toString() {
        return "QCM{" +
                "id_qcm=" + id_qcm +
                ", id_partipitant_U=" + id_partipitant_U +
                ", libelle_question='" + libelle_question + '\'' +
                ", proposition_1='" + proposition_1 + '\'' +
                ", proposition_2='" + proposition_2 + '\'' +
                ", proposition_3='" + proposition_3 + '\'' +
                ", proposition_4='" + proposition_4 + '\'' +
                ", bonne_reponse=" + bonne_reponse +
                ", auteur='" + auteur + '\'' +
                '}';
    }


}
