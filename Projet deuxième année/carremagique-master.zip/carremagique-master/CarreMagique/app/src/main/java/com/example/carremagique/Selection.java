package com.example.carremagique;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Selection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
    }

    public void click3(View view) {
        Intent page= new Intent (this,MainActivity.class);
        page.putExtra("dimension",3);
        finish();
        startActivity(page);
    }
    public void click5(View view) {
        Intent page= new Intent (this,MainActivity.class);
        page.putExtra("dimension",5);
        finish();
        startActivity(page);
    }
    public void click7(View view) {
        Intent page= new Intent (this,MainActivity.class);
        page.putExtra("dimension",7);
        finish();
        startActivity(page);
    }
    public void click9(View view) {
        Intent page= new Intent (this,MainActivity.class);
        page.putExtra("dimension",9);
        finish();
        startActivity(page);
    }
    public void exit(View view) {
        finish();
    }
}