package com.example.carremagique;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private int dimension;
    int longueur;
    int largeur;
    Button tableauButton[][];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent recup= getIntent();
        dimension=recup.getIntExtra("dimension",3);

        tableauButton =new Button[dimension][dimension];
        creationTerrain(dimension);
        jeu(dimension);
        
    }


    private void jeu(int dimension) {

        int xterrain=dimension/2;
        int yterrain=dimension/2-1;

        for (int i = 1; i <=dimension*dimension; i++) {

            tableauButton[yterrain][xterrain].setText(""+i);
            xterrain++;yterrain--;

            if (yterrain<0 && xterrain>dimension-1){//Vérif si X et Y sort du jeu en meme temps(coin haut gauche)
                yterrain=dimension-2;
                xterrain--;
            }
            else if (yterrain<0) {//Verif si Y sort du jeu
                yterrain=dimension-1;
            }
            else if (xterrain>dimension-1){//Verif si X sort du jeu
                xterrain=0;
            }
            else if (tableauButton[yterrain][xterrain].length()>0){
                yterrain--;
                xterrain--;
                if (yterrain<0) {
                    yterrain=dimension-1;
                }
                if (xterrain>dimension-1){
                    xterrain=0;
                }

            }

        }
    }


    public void taillePage(){//Récuperer la taille de l'affichage de l'écran

        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);
        longueur = size.y;
        largeur= size.x;

    }
    public void creationTerrain(int dimension) {

        GridLayout terrain=findViewById(R.id.grid);
        terrain.setColumnCount(dimension);
        terrain.setRowCount(dimension);
        GridLayout.LayoutParams par;

        taillePage();

        int i=0;

        for (int g = 0; g < dimension; g++) {
            for (int j = 0; j < dimension ; j++) {

                Button alpha=new Button(this);
                par=new GridLayout.LayoutParams();
                par.width=largeur/dimension;
                par.height=par.width;
                alpha.setId(i);
                alpha.setLayoutParams(par);
                terrain.addView(alpha);

                tableauButton[g][j]=alpha;

                i++;
            }
        }
    }

    public void exit(View view) {
        Intent page= new Intent (this,Selection.class);
        finish();
        startActivity(page);
    }
}