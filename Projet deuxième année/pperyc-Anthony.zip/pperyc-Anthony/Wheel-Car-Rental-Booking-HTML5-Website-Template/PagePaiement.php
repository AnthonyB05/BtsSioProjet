<?php
include 'head.php';
include "donnePaiement.php";
include 'shopping.php';
include 'footer.php';
?>