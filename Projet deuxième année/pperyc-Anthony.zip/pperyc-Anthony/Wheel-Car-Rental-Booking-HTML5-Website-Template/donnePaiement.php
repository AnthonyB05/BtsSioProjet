<?php
            $prix=2500;
            $nom_voiture="Porsche Cayman ";
            $boxCarteBancaire=$_POST['boxCarteBancaire'];
            $boxExpirationDate=$_POST['boxExpirationDate'];
            $boxCryptogramme=$_POST['boxCryptogramme'];
?>