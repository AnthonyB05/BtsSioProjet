
        <!-- ////////////////////////////////////////////////////////////// -->
        <div class="wheel-start3">
            <img src="images/bg7.jpg" alt="" class="wheel-img">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 padd-lr0">
                        <div class="wheel-start3-body clearfix marg-lg-t255 marg-lg-b75 marg-sm-t190 marg-xs-b30">
                            <h3>Paiement</h3>
                            <ol class="breadcrumb">
                                <li><a href="#">Accueil</a></li>
                                <li><a href="#">Véhicule</a></li>
                                <li class="active">Paiement</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////////////////////////// -->

       

        <div class="container no-padding">
            <div class="row">
                <div class="col-xs-12">
                    <div class="table-responsive wheel-cart">
                        <table class="wheel-table-cart marg-lg-t140 marg-md-t100 marg-sm-t80 marg-xs-t60">
                            <thead>
                                <tr>
                                    <th>Produit</th>
                                    <th>Prix</th>
                                    
                                
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="column-pl">
                                        <i class="fa fa-times"></i>
                                        <img src="images/i42.png" alt="" class="img"> <?php echo "$nom_voiture" ?>
                                    </td>
                                   
                                    <td><?php echo "$prix €" ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
           
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="s-cart-ship">
                        <h5 class="title">Informations de paiement</h5>
                        <form action="https://demos.jeweltheme.com/" method="post" class="s-ship-submit">

                            <input name="nomTitulaire" id="nomTitulaire" class="s-ship-inp" type="text" placeholder="Non Titulaire" required>

                            <input maxlength="9" name="boxCarteBancaire" id="boxCarteBancaire" class="s-ship-inp" type="text" placeholder="Numéro Carte Bancaire"   required>
                           
                            <input  maxlength="2" name="boxExpirationMois" id="boxExpirationMois" class="s-ship-inp" type="text" placeholder="Mois MM" required>

                            <input  maxlength="4" name="boxExpirationAnnee" id="boxExpirationAnnee" class="s-ship-inp" type="text"  placeholder="Année AAAA" required>
         
                            <input  maxlength="3" name="boxCryptogramme" id="boxCryptogramme" class="s-ship-inp" type="text"  placeholder="Cryptogramme XXX" required>

                            

                        </form>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <br/>
                    <br/>
                    <br/>
                    <div class="wheel-order-price marg-lg-t30 marg-lg-b150 marg-sm-b100">
                        <ul>
                            <li class="clearfix wheel-total">
                                <h4>Total du panier</h4>
                                <b><?php echo "$prix €" ?></b>
                            </li>
                        </ul>
                    </div>
                    <button type="submit" role="button" aria-disabled="false" class="wheel-btn  pull-right"  formaction="PageSuitePaiement.php">Paiement</button>
                </div>
            </div>
        </div>
        
        
    