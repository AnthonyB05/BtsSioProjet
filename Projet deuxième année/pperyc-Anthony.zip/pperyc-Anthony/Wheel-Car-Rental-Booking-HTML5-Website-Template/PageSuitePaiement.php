<?php
include 'head.php';
include "donnePaiement.php";
include "validPaie.php";
include 'footer.php';
?>