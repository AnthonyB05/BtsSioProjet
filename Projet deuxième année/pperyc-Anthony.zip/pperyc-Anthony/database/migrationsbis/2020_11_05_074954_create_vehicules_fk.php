<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVehiculesFk extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('Vehicule', function (Blueprint $table) {
            $table->bigInteger('modele_voiture_id')
            ->unsigned()
            ->after('description');
            $table->foreign('modele_voiture_id')
            ->references('id')
            ->on('modele_voitures');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('Vehicule', function (Blueprint $table) {
            //
        });
    }
}
