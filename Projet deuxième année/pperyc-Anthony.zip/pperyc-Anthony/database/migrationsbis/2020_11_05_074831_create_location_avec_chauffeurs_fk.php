<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocationAvecChauffeursFk extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('location_avec_chauffeurs', function (Blueprint $table) {
            $table->bigInteger('location_id')
            ->unsigned();
            $table->foreign('location_id')
            ->references('id')
            ->on('locations');

            $table->primary('location_id');

            $table->bigInteger('formule_avec_chauffeur_id')
            ->unsigned()
            ->after('location_id');
            $table->foreign('formule_avec_chauffeur_id')
            ->references('id')
            ->on('formule_avec_chauffeurs');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('location_avec_chauffeurs', function (Blueprint $table) {
            //
        });
    }
}
