<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFormuleAvecChauffeurFk extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('formule_avec_chauffeurs', function (Blueprint $table) {
            $table->bigInteger('formule_id')
            ->unsigned()
            ->before('lieuDestination');
            $table->foreign('formule_id')
            ->references('id')
            ->on('formules');
            $table->primary('formule_id');
        });
        //test trois
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('formule_avec_chauffeurs', function (Blueprint $table) {
            //
        });
    }
}
