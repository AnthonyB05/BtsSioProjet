<?php
include (app_path().'/includes/head.php');
include (app_path().'/includes/about.php');
include (app_path().'/includes/footer.php');
?>