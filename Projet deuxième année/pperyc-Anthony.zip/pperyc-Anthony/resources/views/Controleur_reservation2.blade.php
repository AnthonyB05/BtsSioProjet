<?php

include (app_path().'/includes/head.php');
include (app_path().'/includes/reservation2.php');
include (app_path().'/includes/footer.php');
?>