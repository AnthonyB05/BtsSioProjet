<?php

include (app_path().'/includes/head.php');
include (app_path().'/includes/car-list-3col2.php');
include (app_path().'/includes/footer.php');
?>