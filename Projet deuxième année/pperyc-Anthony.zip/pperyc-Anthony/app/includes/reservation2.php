
        <?php
$Date_jour = '19 juin';
$Date_heure = '14:30';
$nb_jour = 5;
$hidden="hidden";
$disponible_v1=true;
$disponible_v2=false;
$disponible_v3=true;
$disponible_v4=true;
$disponible_v5=false;
$disponible_v6=false;
$disponible_v7=true;
$disponible_v8=false;
$disponible_v9=false;
?>

        <!-- //////////////////////////////// -->
        <div class="wheel-start3">
            <img src="images/bg7.jpg" alt="" class="wheel-img">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 padd-lr0">
                        <div class="wheel-start3-body clearfix marg-lg-t255 marg-lg-b75 marg-sm-t190 marg-xs-b30">
                            <h3>Choissiez un véhicule</h3>
                            <ol class="breadcrumb">
                                <li><a href="#">Acceuil</a></li>
                                <li><a href="#">Choissiez un véhicule</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////// -->
        <div class="prosuct-wrap">
            <div class="container padd-lr0 xs-padd">
                <div class="row">
                    <div class="col-sm-8">
                        <header class="wheel-header marg-lg-t25 marg-lg-b65">
                            <h3>Voici tout nos véhicules a <span> Paris </span> le <span> 
                            <?php
                           echo "$Date_jour, $Date_heure "
                            ?>
                            </span></h3>
                        </header>
                    </div>
                </div>
                
                    <div class="col-xs-12 col-sm-6 col-md-3" >
                        <div class="wheel-car-list-btn">
                            <a href="#" class="fa fa-th-list " data-list='product-elem-style1'></a>
                            <a href="#" class="fa fa-th Climatisationtive" data-list='product-elem-style2'></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container padd-lr0 xs-padd">
                <div class="product-list product-list2 wheel-bgt clearfix">
                    <form action="/Listevehicule" method="GET">
                    <div class="row">
                        <div   <?php
                                if ($disponible_v1==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div
                                class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div
                                 class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i29.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title" name="nom_voiture_1">2016 Marcedes-Benz SLK</div>
                                        <div class="price-wrap product-cell">
                                            <span name='prix1'>500€</span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i40.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>2 Sièges</li>
                                            <li>2 portes</li>
                                            <li>8,6 L/100km</li>
                                            <li>airbags</li>
                                            <li>auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                               <!--     <form hidden action=# method="post">	 Création d'un formulaire contenant toutes les informations requise  
                                    <?php
                                    $prix=$nb_jour*500
                                    ?>
                                        Prix:  	                <input type="text" value="<?php echo "$prix";?>" name="ncli" />
                                        Nom voiture:			<input type="text" value="m" name="nom" />
    
                                        <button type="submit" class="bouton" role="button"
		                            	aria-disabled="false" formaction="ajouterclient.php">ok</button>  Validation 
                                    </form> -->
                                    <button class="wheel-cheader-but" id='voiture_1'>Choisir</button>
                                    <?php
                                    echo "$prix";
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v2==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i28.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Chevrolet Malibu</div>
                                        <div class="price-wrap product-cell">
                                            <span>550€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i32.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>5 Sièges</li>
                                            <li>4 portes</li>
                                            <li>7,4 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v3==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i27.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">Bugatti Veyron</div>
                                        <div class="price-wrap product-cell">
                                            <span>5 000€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i33.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>2 Sièges</li>
                                            <li>2 portes</li>
                                            <li>24,1 L/100 km</li>
                                            <li>airbags</li>
                                            <li>auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v4==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i31.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Nissan Juke</div>
                                        <div class="price-wrap product-cell">
                                            <span>630€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i35.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>2 Sièges</li>
                                            <li>5 portes</li>
                                            <li>7,8 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                 <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v5==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i30.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Audi S4</div>
                                        <div class="price-wrap product-cell">
                                            <span>1500€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i34.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>5 Sièges</li>
                                            <li>4 portes</li>
                                            <li>9,0 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v6==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i31.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Chevrolet Malibu</div>
                                        <div class="price-wrap product-cell">
                                            <span>850€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i36.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>4 Sièges</li>
                                            <li>2 portes</li>
                                            <li>5,3 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v7==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i27.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">Bugatti Veyron</div>
                                        <div class="price-wrap product-cell">
                                            <span>5 000€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i33.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>4 Sièges</li>
                                            <li>4 portes</li>
                                            <li>10,0 L/100km</li>
                                            <li>airbags</li>
                                            <li>auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v8==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i31.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Nissan Juke</div>
                                        <div class="price-wrap product-cell">
                                            <span>480€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i35.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>4 Sièges</li>
                                            <li>2 portes</li>
                                            <li>5,2 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                        <div <?php
                                if ($disponible_v9==false) {
                                echo "$hidden";
                                }
                                ?> class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i30.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Audi S4</div>
                                        <div class="price-wrap product-cell">
                                            <span>810€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i34.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>5 Sièges</li>
                                            <li>4 portes</li>
                                            <li>6,8 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                    <a href="anthopage.html" class="wheel-cheader-but" target="_blank">Choisir</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>