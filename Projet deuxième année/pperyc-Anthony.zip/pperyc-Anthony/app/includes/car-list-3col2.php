
        <!-- //////////////////////////////// -->
        <div class="wheel-start3">
            <img src="images/bg7.jpg" alt="" class="wheel-img">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 padd-lr0">
                        <div class="wheel-start3-body clearfix marg-lg-t255 marg-lg-b75 marg-sm-t190 marg-xs-b30">
                            <h3>Liste des véhicules</h3>
                            <ol class="breadcrumb">
                                <li><a href="#">Acceuil</a></li>
                                <li><a href="#">Liste des véhicules</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ////////////////////////////////////////// -->
        <div class="prosuct-wrap">
            <div class="container padd-lr0 xs-padd">
                <div class="row">
                    <div class="col-sm-8">
                        <header class="wheel-header marg-lg-t25 marg-lg-b65">
                            <h3>Voici tout nos véhicules <span> libre ou non</span></h3>
                        </header>
                    </div>
                </div>
                
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <div class="wheel-car-list-btn">
                            <a href="#" class="fa fa-th-list " data-list='product-elem-style1'></a>
                            <a href="#" class="fa fa-th Climatisationtive" data-list='product-elem-style2'></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container padd-lr0 xs-padd">
                <div class="product-list product-list2 wheel-bgt clearfix">
                    <div class="row">
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i29.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Marcedes-Benz SLK</div>
                                        <div class="price-wrap product-cell">
                                            <span>500€</span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i40.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>2 Sièges</li>
                                            <li>2 portes</li>
                                            <li>8,6 L/100km</li>
                                            <li>airbags</li>
                                            <li>auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i28.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Chevrolet Malibu</div>
                                        <div class="price-wrap product-cell">
                                            <span>550€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i32.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>5 Sièges</li>
                                            <li>4 portes</li>
                                            <li>7,4 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i27.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">Bugatti Veyron</div>
                                        <div class="price-wrap product-cell">
                                            <span>5 000€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i33.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>2 Sièges</li>
                                            <li>2 portes</li>
                                            <li>24,1 L/100 km</li>
                                            <li>airbags</li>
                                            <li>auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i31.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Nissan Juke</div>
                                        <div class="price-wrap product-cell">
                                            <span>630€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i35.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>2 Sièges</li>
                                            <li>5 portes</li>
                                            <li>7,8 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel</li>
                                            <li>Climatisation</li>
                                        </ul>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i30.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Audi S4</div>
                                        <div class="price-wrap product-cell">
                                            <span>1500€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i34.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>5 Sièges</li>
                                            <li>4 portes</li>
                                            <li>9,0 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i31.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Chevrolet Malibu</div>
                                        <div class="price-wrap product-cell">
                                            <span>850€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i36.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>4 Sièges</li>
                                            <li>2 portes</li>
                                            <li>5,3 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i27.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">Bugatti Veyron</div>
                                        <div class="price-wrap product-cell">
                                            <span>5 000€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i33.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>4 Sièges</li>
                                            <li>4 portes</li>
                                            <li>10,0 L/100km</li>
                                            <li>airbags</li>
                                            <li>auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i31.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Nissan Juke</div>
                                        <div class="price-wrap product-cell">
                                            <span>480€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i35.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>4 Sièges</li>
                                            <li>2 portes</li>
                                            <li>5,2 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel</li>
                                            <li>Climatisation</li>
                                        </ul>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4  col-md-6">
                            <div class="product-elem-style2 product-elem-style  wheel-bg1 clearfix">
                                <div class="product-table2">
                                    <div class="img-wrap img-wrap2 product-cell">
                                        <img src="images/i30.jpg" alt="img" class="img-responsive">
                                    </div>
                                </div>
                                <div class="product-table3  ">
                                    <div class="text-wrap text-wrap2 product-cell">
                                        <div class="title">2016 Audi S4</div>
                                        <div class="price-wrap product-cell">
                                            <span>810€
                                            </span><sup>00</sup>/Jour
                                        </div>
                                    </div>
                                    <div class="img-wrap img-wrap3 product-cell">
                                        <img src="images/i34.jpg" alt="img" class="img-responsive">
                                    </div>
                                    <div class="text-wrap  text-wrap3 product-cell">
                                        <ul class="metadata metadata2">
                                            <li>5 Sièges</li>
                                            <li>4 portes</li>
                                            <li>6,8 L/100km</li>
                                            <li>airbags</li>
                                            <li>manuel/auto</li>
                                            <li>Climatisation</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>