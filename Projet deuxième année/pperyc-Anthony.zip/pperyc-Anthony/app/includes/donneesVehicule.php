<?php
            $prix=2500;
            $image_voiture="images/i41.png";
            $nom_voiture="Porsche Cayman ";
?>