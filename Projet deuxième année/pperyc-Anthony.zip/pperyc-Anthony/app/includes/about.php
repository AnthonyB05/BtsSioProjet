
        <!-- ////////////////////////////////////////////////////////////// -->
        <div class="wheel-start3">
            <img src="images/bg7.jpg" alt="" class="wheel-img">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 padd-lr0">
                        <div class="wheel-start3-body clearfix marg-lg-t255 marg-lg-b75 marg-sm-t190 marg-xs-b30">
                            <h3>About Us</h3>
                            <ol class="breadcrumb">
                                <li><a href="index.html">Accueil</a></li>
                                <li><a href="#"> About Us </a></li>
                               
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /////////////////////////////////////////////////// -->
        <div class="container padd-lr0">
            <div class="row">
                <div class="col-md-6 ">
                    <div class="wheel-info-img  marg-lg-t150 marg-lg-b150 marg-md-t100 marg-md-b100">
                        <img src="images/i7.png" alt="" class="wheel-img">
                    </div>
                </div>
                <div class="col-md-6 ">
                    <div class="wheel-info-text  marg-lg-t150 marg-lg-b150 marg-md-t100 marg-md-b100 marg-sm-t50 marg-sm-b50">
                        <div class="wheel-header">
                            <h5>NOTRE VALEUR  </h5>
                            <h3>Nous sommes proches de nos <span>clients</span></h3>
                        </div>
                        <p>Rent Your Car a mis le client au cœur de sa stratégie. La proximité de la marque avec ses clients nous permet d’assurer un service de qualité sur tout le territoire. Notre enseigne de location de voitures est ainsi devenue en quelques années, un acteur incontournable de la vie locale. Rent Your Car a apporté à ses clients la mobilité sans contraintes et nous exigeons de la part de notre réseau une qualité de service irréprochable.</p>
                    </div>
                </div>
            </div>
        </div>
        