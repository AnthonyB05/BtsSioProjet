<?php

namespace App\Http\Controllers;

use App\Models\Banque;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class BanqueController extends Controller
{
   
    public function create()
    {
        return view('banque');
    }
    public function store(Request $request)
    {

        $request->validate([
            'numero' => ['required', 'string','min:16','max:16'],
            'nom' => ['required', 'string', 'max:255'],
            'mois' => ['required','string','min:2','max:2'],
            'annee' => ['required','string','min:4','max:4'],
            'crypto' => ['required', 'string','min:3', 'max:3'],
        ]);
        //Banque::create($request->all());

        $banque = new \App\Models\Banque;
        $banque->numero = $request->numero;
        $banque->nom = $request->nom;
        $banque->mois = $request->mois;
        $banque->annee = $request->annee;
        $banque->crypto = $request->crypto;
        $banque->save();

        return view('PageSuitePaiement');

        return "C'est bien enregistré !";
    }
    
}
