<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FormuleAvecChauffeur extends Model
{
    protected $guarded = [];
    public function location_sans_chauffeurs() {
        return $this->hasMany(LocationSansChauffeur::class,'location_id');
    }
    use HasFactory;
}
