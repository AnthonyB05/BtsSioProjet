<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/PageAbout', function () {
    return view('PageAbout');
});

/*Route::get('/Shopping', function () {
    return view('Shopping');
});
/*
Route::get('/PageSuitePaiement', function () {
    return view('PageSuitePaiement');
});*/


use App\Http\Controllers\BanqueController;
Route::get('banque', [BanqueController::class, 'create'])->name('banque.create');
Route::post('banque', [BanqueController::class, 'store'])->name('banque.store');
//Route::post('/PagePaiement', [BanqueController::class, 'verifclient']);
//Route::resource('banques', BanqueController::class);












