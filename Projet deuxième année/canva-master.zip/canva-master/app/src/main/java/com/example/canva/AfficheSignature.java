package com.example.canva;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class AfficheSignature extends AppCompatActivity {

    Signature signature;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affiche_signature);

        LinearLayout linearLayout = findViewById(R.id.LinearLayout);
        linearLayout.setBackgroundColor(Color.GRAY);
        LinearLayout lL1 = findViewById(R.id.lL1);
        lL1.setBackgroundColor(Color.GRAY);
        LinearLayout lL2 = findViewById(R.id.lL2);
        lL2.setBackgroundColor(Color.WHITE);

        Intent capture = getIntent();
        String sign = capture.getStringExtra("signature");

        signature = new Signature(this,null);
        signature.dessine(sign);
        lL2.addView(signature, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

    }

    public void cancel(View view) {
        finish();
    }

    public class Signature extends View {
        // variables nécessaire au dessin
       private Canvas canvas;
        private Bitmap bitmap;
        public Signature(Context context, AttributeSet attrs) {
            super(context, attrs);


        }
        //gestion du dessin
        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            canvas.drawBitmap(bitmap,0,0,null);
        }

        public void dessine(String encodedString) {
            try {
                byte[] encodeByte = Base64
                        .decode(encodedString, Base64.DEFAULT);
                bitmap = BitmapFactory.decodeByteArray(encodeByte, 0,
                        encodeByte.length);
                bitmap = bitmap.copy(bitmap.getConfig(), true);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "error dessine",
                        Toast.LENGTH_LONG).show();
            }
            canvas = new Canvas(bitmap);
            this.draw(canvas);
        }
    }
}