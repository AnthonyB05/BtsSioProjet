package com.example.morpion5score;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class PageAccueil extends AppCompatActivity {

    protected CharSequence joueur1;
    protected CharSequence joueur2;

    private TextView joueur1Txt;
    private TextView joueur2Txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_niveau);

        joueur1Txt=(TextView)findViewById(R.id.NomJoueur1);
        joueur2Txt=(TextView)findViewById(R.id.NomJoueur2);

    }

    public void exit(View view) {
        finish();
    }

    public void niv1(View view) {
        joueur1=joueur1Txt.getText();
        joueur2=joueur2Txt.getText();

        Intent page= new Intent (this, Jeu.class);
        page.putExtra("joueur1",joueur1);
        page.putExtra("joueur2",joueur2);
        page.putExtra("niveau",1);
        finish();
        startActivity(page);
    }
    public void niv2(View view) {
        joueur1=joueur1Txt.getText();
        joueur2="IA";
        Intent page= new Intent (this, Jeu.class);
        page.putExtra("joueur1",joueur1);
        page.putExtra("joueur2",joueur2);
        page.putExtra("niveau",2);
        finish();
        startActivity(page);
    }
    public void niv3(View view) {
        joueur1=joueur1Txt.getText();
        joueur2="IA";
        Intent page= new Intent (this, Jeu.class);
        page.putExtra("joueur1",joueur1);
        page.putExtra("joueur2",joueur2);
        page.putExtra("niveau",3);
        finish();
        startActivity(page);
    }
    public void niv4(View view) {
        joueur1="IA1";
        joueur2="IA2";
        Intent page= new Intent (this, Jeu.class);
        page.putExtra("joueur1",joueur1);
        page.putExtra("joueur2",joueur2);
        page.putExtra("niveau",4);
        finish();
        startActivity(page);
    }

    public void score(View view) {
        Intent page= new Intent (this, PageScore.class);
       // finish();
        startActivity(page);
    }
}

