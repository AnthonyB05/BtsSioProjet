package com.example.morpion5score;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLiteHelper extends SQLiteOpenHelper {

    public static final String TABLE_SCORE = "scores";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_J1 = "joueur1";
    public static final String COLUMN_SCORE1 = "score1";
    public static final String COLUMN_J2 = "joueur2";
    public static final String COLUMN_SCORE2 = "score2";

    private static final String DATABASE_NAME = "score.db";
    private static final int DATABASE_VERSION = 1;

    // Commande sql pour la création de la base de données
    private static final String DATABASE_CREATE = "create table "
            + TABLE_SCORE + "(" + COLUMN_ID
            + " integer primary key autoincrement, " + COLUMN_J1
            + " text not null,"+COLUMN_SCORE1 +" integer not null,"+COLUMN_J2
            + " text not null,"+COLUMN_SCORE2 +" integer not null);";

    public MySQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override//création base de données
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(MySQLiteHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCORE);
        onCreate(db);
    }
}
