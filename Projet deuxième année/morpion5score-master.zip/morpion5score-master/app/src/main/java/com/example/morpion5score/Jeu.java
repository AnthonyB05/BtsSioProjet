package com.example.morpion5score;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;
import java.util.Random;


public class Jeu extends AppCompatActivity {


    private ImageButton prem;

    private int a;
    private int coup;
    private int niv;
    private int scorej1;
    private int scorej2;
    private int iaLigne;
    private int iaColonne;
    private int opti;

    private boolean egalite;

    private Random random;

    private CharSequence NomJ1;
    private CharSequence NomJ2;

    private TextView joueurTxt;
    private TextView joueurX;
    private TextView joueurO;
    private TextView score;

    private String tagI1;
    private String tagI2;
    private String tagI3;
    private String tagI4;
    private String tagI5;
    private String tagI6;
    private String tagI7;
    private String tagI8;
    private String tagI9;
    private String tagI10;
    private String tagI11;
    private String tagI12;
    private String tagI13;
    private String tagI14;
    private String tagI15;
    private String tagI16;
    private String tagI17;
    private String tagI18;
    private String tagI19;
    private String tagI20;
    private String tagI21;
    private String tagI22;
    private String tagI23;
    private String tagI24;
    private String tagI25;

    private String tag[][];
    private ImageButton liste[][];
    private int terrainOpti[][];

    private ScoreData data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jeu);

        init();
        random();
        liste();
        initia();
        niv4();

    }

    public void onClick(View view) {

        if (niv==1){
            if (a==1){
                joueurTxt.setText("O");
                prem = (ImageButton)view;
                prem.setImageResource(R.drawable.croix);
                prem.setTag("croix");
                prem.setClickable(false);
                a=2;
                coup+=1;
                winCroix(coup);
            }else{
                joueurTxt.setText("X");
                prem = (ImageButton)view;
                prem.setImageResource(R.drawable.cercle);
                prem.setTag("cercle");
                prem.setClickable(false);
                a=1;
                coup+=1;
                winCercle(coup);
            }
        }

        if (niv==2){
            if (a==1){

                joueurTxt.setText("O");
                prem = (ImageButton)view;
                prem.setImageResource(R.drawable.croix);
                prem.setTag("croix");
                prem.setClickable(false);
                coup+=1;
                a=2;
                joueurTxt.setText("X");

                winCroix(coup);

                //---------------------

                random= new Random();
                while (a==2){

                    iaLigne=0+random.nextInt(5);
                    iaColonne=0+random.nextInt(5);
                    tag();
                    if (tag[iaLigne][iaColonne]==null){

                        liste[iaLigne][iaColonne].setTag("cercle");
                        liste[iaLigne][iaColonne].setImageResource(R.drawable.cercle);
                        liste[iaLigne][iaColonne].setClickable(false);
                        a=1;
                        coup+=1;

                    }
                }
                winCercle(coup);

            }
        }
        if (niv==3){
           if (a==1){
               joueurTxt.setText("O");
               prem = (ImageButton)view;
               prem.setImageResource(R.drawable.croix);
               prem.setTag("croix");
               prem.setClickable(false);
               coup+=1;

               joueurTxt.setText("X");
               winCroix(coup);

               //---------------------
               niv3();
           }
        }

    }

    private void winCroix(int coup) {

        tag();


        //ligne
        for (int i = 0; i < 5; i++) {
            if( tag[i][0]!= null && tag[i][0].equals("croix") && tag[i][0]==tag[i][1] &&tag[i][0]==tag[i][2]&&tag[i][0]==tag[i][3]&&tag[i][0]==tag[i][4] ){
                joueurTxt.setText(NomJ1+" a gagné");
                scorej1+=1;
                egalite = false;
                fin();
            }

        }
        //colonne
        for (int j = 0; j < 5; j++) {
            if( tag[0][j]!= null && tag[0][j].equals("croix") && tag[0][j]==tag[1][j] &&tag[0][j]==tag[2][j]&&tag[0][j]==tag[3][j]&&tag[0][j]==tag[4][j] ){
                joueurTxt.setText(NomJ1+" a gagné");
                scorej1+=1;
                egalite = false;
                fin();
            }
        }
        //backslash
        if( tag[0][0]!= null && tag[0][0].equals("croix") && tag[0][0]==tag[1][1] &&tag[0][0]==tag[2][2]&&tag[0][0]==tag[3][3]&&tag[0][0]==tag[4][4] ){
            joueurTxt.setText(NomJ1+" a gagné");
            scorej1+=1;
            egalite = false;
            fin();
        }

        //slash
        if( tag[0][4]!= null && tag[0][4].equals("croix") && tag[0][4]==tag[1][3] &&tag[0][4]==tag[2][2]&&tag[0][4]==tag[3][1]&&tag[0][4]==tag[4][0] ){
            joueurTxt.setText(NomJ1+" a gagné");
            scorej1+=1;
            egalite = false;
            fin();
        }

        if (coup==25){
            egalite();
        }

    }
    private void winCercle(int coup) {

        tag();

        //ligne
        for (int i = 0; i < 5; i++) {
            if( tag[i][0]!= null && tag[i][0].equals("cercle") && tag[i][0]==tag[i][1] &&tag[i][0]==tag[i][2]&&tag[i][0]==tag[i][3]&&tag[i][0]==tag[i][4] ){
                joueurTxt.setText(NomJ2+" a gagné");
                scorej2+=1;
                egalite = false;
                fin();
            }
        }
        //colonne
        for (int j = 0; j < 5; j++) {
            if( tag[0][j]!= null && tag[0][j].equals("cercle") && tag[0][j]==tag[1][j] &&tag[0][j]==tag[2][j]&&tag[0][j]==tag[3][j]&&tag[0][j]==tag[4][j] ){
                joueurTxt.setText(NomJ2+" a gagné");
                scorej2+=1;
                egalite = false;
                fin();
            }
        }
        //backslash
        if( tag[0][0]!= null && tag[0][0].equals("cercle") && tag[0][0]==tag[1][1] &&tag[0][0]==tag[2][2]&&tag[0][0]==tag[3][3]&&tag[0][0]==tag[4][4] ){
            joueurTxt.setText(NomJ2+" a gagné");
            scorej2+=1;
            egalite = false;
            fin();
        }

        //slash
        if( tag[0][4]!= null && tag[0][4].equals("cercle") && tag[0][4]==tag[1][3] &&tag[0][4]==tag[2][2]&&tag[0][4]==tag[3][1]&&tag[0][4]==tag[4][0] ){
            joueurTxt.setText(NomJ2+" a gagné");
            scorej2+=1;
            egalite = false;
            fin();
        }

        if (coup==25){
            egalite();
        }

    }

    private void init(){
        Intent recup = getIntent();
        NomJ1=recup.getCharSequenceExtra("joueur1");
        NomJ2=recup.getCharSequenceExtra("joueur2");
        niv=recup.getIntExtra("niveau",0);

        scorej1=recup.getIntExtra("scorej1",0);
        scorej2=recup.getIntExtra("scorej2",0);

        joueurTxt=(TextView)findViewById(R.id.joueurTxt);
        joueurX=(TextView)findViewById(R.id.textViewJoueur1);
        joueurO=(TextView)findViewById(R.id.textViewJoueur2);
        score=(TextView)findViewById(R.id.score);


        joueurX.setText(NomJ1+" : "+ System.getProperty("line.separator") +"tu joues les X" );
        joueurO.setText(NomJ2+" : "+ System.getProperty("line.separator") +"tu joues les 0" );
        score.setText(scorej1+" : "+scorej2);

        egalite = true;
        coup=0;

    }
    private void initia(){
        if (niv!=1 && niv!=3) {
            if (a==2){
                joueurTxt.setText("X");
                /*
                prem = (ImageButton)view;
                prem.setImageResource(R.drawable.cercle);
                prem.setTag("cercle");
                prem.setClickable(false);
                */
                random = new Random();
                iaLigne = 0 + random.nextInt(4);
                iaColonne = 0 + random.nextInt(4);
                tag();
                if (tag[iaLigne][iaColonne]==null){
                    liste[iaLigne][iaColonne].setTag("cercle");
                    liste[iaLigne][iaColonne].setImageResource(R.drawable.cercle);
                    liste[iaLigne][iaColonne].setClickable(false);
                    a=1;
                    coup+=1;
                }
                winCercle(coup);
            }
        }
        else if(niv==3){
            terrainOpti=new int[5][5];
            if (a==2){
                niv3();
            }
        }
    }
    private void fin(){
        score.setText(scorej1+" : "+scorej2);
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                liste[i][j].setClickable(false);
            }
        }
    }
    private void egalite(){
        fin();
        if (egalite==true) {
            joueurTxt.setText("Egalite");
        }

    }
    private String[][] tag(){

        tag= new String[5][5];

        tagI1 = (String) liste[0][0].getTag();
        tagI2 = (String) liste[0][1].getTag();
        tagI3 = (String) liste[0][2].getTag();
        tagI4 = (String) liste[0][3].getTag();
        tagI5 = (String) liste[0][4].getTag();

        tagI6 = (String) liste[1][0].getTag();
        tagI7 = (String) liste[1][1].getTag();
        tagI8 = (String) liste[1][2].getTag();
        tagI9 = (String) liste[1][3].getTag();
        tagI10 = (String) liste[1][4].getTag();

        tagI11 = (String) liste[2][0].getTag();
        tagI12 = (String) liste[2][1].getTag();
        tagI13 = (String) liste[2][2].getTag();
        tagI14 = (String) liste[2][3].getTag();
        tagI15 = (String) liste[2][4].getTag();

        tagI16 = (String) liste[3][0].getTag();
        tagI17 = (String) liste[3][1].getTag();
        tagI18 = (String) liste[3][2].getTag();
        tagI19 = (String) liste[3][3].getTag();
        tagI20 = (String) liste[3][4].getTag();

        tagI21 = (String) liste[4][0].getTag();
        tagI22 = (String) liste[4][1].getTag();
        tagI23 = (String) liste[4][2].getTag();
        tagI24 = (String) liste[4][3].getTag();
        tagI25 = (String) liste[4][4].getTag();

        tag[0][0]=tagI1;
        tag[0][1]=tagI2;
        tag[0][2]=tagI3;
        tag[0][3]=tagI4;
        tag[0][4]=tagI5;

        tag[1][0]=tagI6;
        tag[1][1]=tagI7;
        tag[1][2]=tagI8;
        tag[1][3]=tagI9;
        tag[1][4]=tagI10;

        tag[2][0]=tagI11;
        tag[2][1]=tagI12;
        tag[2][2]=tagI13;
        tag[2][3]=tagI14;
        tag[2][4]=tagI15;

        tag[3][0]=tagI16;
        tag[3][1]=tagI17;
        tag[3][2]=tagI18;
        tag[3][3]=tagI19;
        tag[3][4]=tagI20;

        tag[4][0]=tagI21;
        tag[4][1]=tagI22;
        tag[4][2]=tagI23;
        tag[4][3]=tagI24;
        tag[4][4]=tagI25;

        return tag;

    }
    public void liste(){

        liste=new ImageButton[5][5];

        liste[0][0]=(ImageButton)findViewById(R.id.imageButton1);
        liste[0][1]=(ImageButton)findViewById(R.id.imageButton2);
        liste[0][2]=(ImageButton)findViewById(R.id.imageButton3);
        liste[0][3]=(ImageButton)findViewById(R.id.imageButton4);
        liste[0][4]=(ImageButton)findViewById(R.id.imageButton5);

        liste[1][0]=(ImageButton)findViewById(R.id.imageButton6);
        liste[1][1]=(ImageButton)findViewById(R.id.imageButton7);
        liste[1][2]=(ImageButton)findViewById(R.id.imageButton8);
        liste[1][3]=(ImageButton)findViewById(R.id.imageButton9);
        liste[1][4]=(ImageButton)findViewById(R.id.imageButton10);

        liste[2][0]=(ImageButton)findViewById(R.id.imageButton11);
        liste[2][1]=(ImageButton)findViewById(R.id.imageButton12);
        liste[2][2]=(ImageButton)findViewById(R.id.imageButton13);
        liste[2][3]=(ImageButton)findViewById(R.id.imageButton14);
        liste[2][4]=(ImageButton)findViewById(R.id.imageButton15);

        liste[3][0]=(ImageButton)findViewById(R.id.imageButton16);
        liste[3][1]=(ImageButton)findViewById(R.id.imageButton17);
        liste[3][2]=(ImageButton)findViewById(R.id.imageButton18);
        liste[3][3]=(ImageButton)findViewById(R.id.imageButton19);
        liste[3][4]=(ImageButton)findViewById(R.id.imageButton20);

        liste[4][0]=(ImageButton)findViewById(R.id.imageButton21);
        liste[4][1]=(ImageButton)findViewById(R.id.imageButton22);
        liste[4][2]=(ImageButton)findViewById(R.id.imageButton23);
        liste[4][3]=(ImageButton)findViewById(R.id.imageButton24);
        liste[4][4]=(ImageButton)findViewById(R.id.imageButton25);
    }
    public void random(){
        random= new Random();
        a=1+random.nextInt(2);
        if (a==1){
            joueurTxt.setText("X");
        }else{
            joueurTxt.setText("O");
        }
    }
    public void reset(View view) {

        Intent reset= new Intent (this, Jeu.class);
        reset.putExtra("joueur1",NomJ1);
        reset.putExtra("joueur2",NomJ2);
        reset.putExtra("scorej1",scorej1);
        reset.putExtra("scorej2",scorej2);
        reset.putExtra("niveau",niv);

        finish();
        startActivity(reset);

    }
    public void database(){
        data = new ScoreData(this);//création d'une connexion avec la database
        ScoreData.open();

        data.createScore(NomJ1.toString(),scorej1,NomJ2.toString(),scorej2);//création score partie
    }

    public void change(View view) {

        database();
        Intent change= new Intent (this,PageAccueil.class);

        finish();
        startActivity(change);
    }

    public void calculOpti(){
        tag();

        opti=0;

    }

    public void niv3(){



        calculOpti();

        if (coup==0){
            liste[2][2].setTag("cercle");
            liste[2][2].setImageResource(R.drawable.cercle);
            liste[2][2].setClickable(false);
            a=1;
            coup+=1;
        }
        else if (coup == 1) {
            if (tag[0][0] == "croix" || tag[0][4] == "croix" || tag[4][0] == "croix" || tag[4][4] == "croix") {
                liste[2][2].setTag("cercle");
                liste[2][2].setImageResource(R.drawable.cercle);
                liste[2][2].setClickable(false);
                a = 1;
                coup += 1;
            }

        }
        else if(coup == 2){

        }

        else if(coup == 3){

        }
        else if (coup == 4){

        }
        else if (coup == 5){

        }
        else if (coup == 6){

        }
        else if (coup == 7){

        }
        else if (coup == 8){

        }
        else if (coup == 9){

        }
        else if (coup == 10){

        }
        else if (coup == 11){

        }
        else if (coup == 12){

        }
        else if (coup == 13){

        }
        else if (coup == 14){

        }
        else if (coup == 15){

        }
        else if (coup == 16){

        }
        else if (coup == 17){

        }
        else if (coup == 18){

        }
        else if (coup == 19){

        }
        else if (coup == 20){

        }
        else if (coup == 21){

        }
        else if (coup == 22){

        }
        else if (coup == 23){

        }
        else if (coup == 24){

        }
        else if (coup == 25){

        }


    }//EN COURS
    public void niv4()  {
        if (niv == 4) {
            if (a == 1) {
                while (coup<24 && egalite==true) {

                    random = new Random();
                    while (a == 1) {
                        iaLigne = 0 + random.nextInt(5);
                        iaColonne = 0 + random.nextInt(5);
                        tag();
                        if (tag[iaLigne][iaColonne] == null) {
                            liste[iaLigne][iaColonne].setTag("croix");
                            liste[iaLigne][iaColonne].setImageResource(R.drawable.croix);
                            liste[iaLigne][iaColonne].setClickable(false);
                            a = 2;
                            coup += 1;
                        }
                    }

                    winCroix(coup);

                    random = new Random();
                    while (a == 2) {
                        iaLigne = 0 + random.nextInt(5);
                        iaColonne = 0 + random.nextInt(5);
                        tag();
                        if (tag[iaLigne][iaColonne] == null) {
                            liste[iaLigne][iaColonne].setTag("cercle");
                            liste[iaLigne][iaColonne].setImageResource(R.drawable.cercle);
                            liste[iaLigne][iaColonne].setClickable(false);
                            a = 1;
                            coup += 1;
                        }
                    }
                    winCercle(coup);

                }
            }
        }
    }

}
