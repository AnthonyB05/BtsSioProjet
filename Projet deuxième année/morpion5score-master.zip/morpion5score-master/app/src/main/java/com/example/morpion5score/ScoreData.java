package com.example.morpion5score;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ScoreData {
    // Champs de la base de données
    private static SQLiteDatabase database;
    private static MySQLiteHelper dbHelper;
    private String[] allColumns = { MySQLiteHelper.COLUMN_ID, MySQLiteHelper.COLUMN_J1,MySQLiteHelper.COLUMN_SCORE1,MySQLiteHelper.COLUMN_J2,MySQLiteHelper.COLUMN_SCORE2, };//insérer toutes les colonnes de la database

    public ScoreData(Context context) {
        dbHelper = new MySQLiteHelper(context);
    }

    public static void open() throws SQLException {//ouvre connexion à la database
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public Score createScore(String J1,int scoreJ1,String J2,int scoreJ2) {
        ContentValues values = new ContentValues();
        values.put(MySQLiteHelper.COLUMN_J1, J1);
        values.put(MySQLiteHelper.COLUMN_SCORE1, scoreJ1);
        values.put(MySQLiteHelper.COLUMN_J2, J2);
        values.put(MySQLiteHelper.COLUMN_SCORE2, scoreJ2);


        long insertId = database.insert(MySQLiteHelper.TABLE_SCORE, null,
                values);
        Cursor cursor = database.query(MySQLiteHelper.TABLE_SCORE,
                allColumns, MySQLiteHelper.COLUMN_ID + " = " + insertId, null,
                null, null, null);
        cursor.moveToFirst();
        Score newScore = cursorToScore(cursor);
        cursor.close();
        return newScore;
    }

    public void deleteScore(Score score) {
        long id = score.getId();
        System.out.println("Comment deleted with id: " + id);
        database.delete(MySQLiteHelper.TABLE_SCORE, MySQLiteHelper.COLUMN_ID
                + " = " + id, null);
    }

    public List<Score> getAllScores() {
        List<Score> scores = new ArrayList<Score>();

        Cursor cursor = database.query(MySQLiteHelper.TABLE_SCORE,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Score score = cursorToScore(cursor);
            scores.add(score);
            cursor.moveToNext();
        }
        // assurez-vous de la fermeture du curseur
        cursor.close();
        return scores;
    }

    private Score cursorToScore(Cursor cursor) {
        Score score = new Score();
        score.setId(cursor.getLong(0));
        score.setJoueur1(cursor.getString(1));
        score.setScoreJ1(cursor.getInt(2));
        score.setJoueur2(cursor.getString(3));
        score.setScoreJ2(cursor.getInt(4));
        return score;
    }

}



