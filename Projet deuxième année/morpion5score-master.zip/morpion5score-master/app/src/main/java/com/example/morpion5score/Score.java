package com.example.morpion5score;

public class Score {

    private long id;
    private String joueur1;
    private String joueur2;
    private int scoreJ1;
    private int scoreJ2;

    public  long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getJoueur1() {
        return joueur1;
    }

    public void setJoueur1(String joueur1) {
        this.joueur1 = joueur1;
    }

    public String getJoueur2() {
        return joueur2;
    }

    public void setJoueur2(String joueur2) {
        this.joueur2 = joueur2;
    }

    public int getScoreJ1() {
        return scoreJ1;
    }

    public void setScoreJ1(int scoreJ1) {
        this.scoreJ1 = scoreJ1;
    }

    public int getScoreJ2() {
        return scoreJ2;
    }

    public void setScoreJ2(int scoreJ2) {
        this.scoreJ2 = scoreJ2;
    }

    // Sera utilisée par ArrayAdapter dans la ListView
    @Override
    public String toString() {
        return   joueur1 + "    " + scoreJ1  + " - " + scoreJ2  + "    " + joueur2 ;
    }
}
