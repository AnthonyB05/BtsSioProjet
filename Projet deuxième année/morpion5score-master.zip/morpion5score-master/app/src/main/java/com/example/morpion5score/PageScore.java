package com.example.morpion5score;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.List;
import java.util.Random;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

public class PageScore extends ListActivity {
    private ScoreData data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        data = new ScoreData(this);//création d'une connexion avec la database
        data.open();

        List<Score> values = data.getAllScores();//recupere touts les scores
        ArrayAdapter<Score> adapter = new ArrayAdapter<Score>(this,//affiche les scores dans la listeview
                android.R.layout.simple_list_item_1, values);
        setListAdapter(adapter);
    }

    public void supprimer(View view) {//supprimer le plus ancien score
        ArrayAdapter<Score> adapter = (ArrayAdapter<Score>) getListAdapter();
        Score score=null;
        if (getListAdapter().getCount() > 0) {
            score = (Score) getListAdapter().getItem(0);
            data.deleteScore(score);
            adapter.remove(score);
        }

    }
}